#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
# 
#   http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#
from xml.dom.minidom import parse, parseString, Node
from io import StringIO
from stat import S_ISDIR
from errno import ENOENT, ESRCH
import os
import os.path
import filecmp
import re

class Template:
    """
    Expandable File Template - This class is instantiated each time a
    template is to be expanded.
    """
    def __init__(self, filename, handler):
        self.filename = filename
        self.handler = handler
        self.handler.initExpansion()
        self.writing = 0  # 0 => write output lines; >0 => recursive depth of conditional regions

    def expandLine(self, line, stream, obj):
        cursor = 0
        while True:
            sub = line.find("/*MGEN:", cursor)
            if sub == -1:
                if self.writing == 0:
                    stream.write(line[cursor:])
                return

            subend = line.find("*/", sub)
            if self.writing == 0:
                stream.write(line[cursor:sub])
            cursor = subend + 2
            tag = line[sub:subend]

            if tag.startswith("/*MGEN:IF("):
                if self.writing == 0:
                    close = tag.find(")")
                    if close == -1: raise ValueError("Missing ')' on condition")
                    cond = tag[10:close]
                    dotPos = cond.find(".")
                    if dotPos == -1: raise ValueError(f"Invalid condition tag: {cond}")
                    tagObject = cond[:dotPos]
                    tagName = cond[dotPos + 1:]
                    if not self.handler.testCondition(obj, tagObject, tagName):
                        self.writing += 1
                else:
                    self.writing += 1
            elif tag.startswith("/*MGEN:ENDIF"):
                if self.writing > 0:
                    self.writing -= 1
            else:
                equalPos = tag.find("=")
                if equalPos == -1:
                    dotPos = tag.find(".")
                    if dotPos == -1: raise ValueError(f"Invalid tag: {tag}")
                    tagObject = tag[7:dotPos]
                    tagName = tag[dotPos + 1:]
                    if self.writing == 0:
                        self.handler.substHandler(obj, stream, tagObject, tagName)
                else:
                    tagKey = tag[7:equalPos]
                    tagVal = tag[equalPos + 1:]
                    if self.writing == 0:
                        self.handler.setVariable(tagKey, tagVal)

    def expand(self, obj):
        stream = StringIO()
        with open(self.filename) as fd:
            for line in fd:
                self.expandLine(line, stream, obj)
        return stream

class Makefile:
    """ Object representing a makefile fragment """
    def __init__(self, filelists, templateFiles, packagelist):
        self.filelists = filelists
        self.templateFiles = templateFiles
        self.packagelist = packagelist

    def genGenSources(self, stream, variables):
        mdir = variables["mgenDir"]
        sdir = variables["specDir"]
        stream.write(f"{mdir}/qmf-gen \\\n")
        stream.write(f"    {mdir}/qmfgen/generate.py \\\n")
        stream.write(f"    {mdir}/qmfgen/schema.py \\\n")
        stream.write(f"    {mdir}/qmfgen/management-types.xml \\\n")
        stream.write(f"    {sdir}/management-schema.xml")
        for template in self.templateFiles:
            stream.write(f" \\\n    {mdir}/qmfgen/templates/{template}")

    def _write_file_list(self, stream, files):
        first = True
        for file in files:
            if not first: stream.write(" \\\n    ")
            stream.write(file)
            first = False

    def genGenCppFiles(self, stream, variables):
        self._write_file_list(stream, self.filelists["cpp"])

    def genGenHFiles(self, stream, variables):
        self._write_file_list(stream, self.filelists["h"])

    def genGeneratedFiles(self, stream, variables):
        first = True
        prefix = variables.get("genprefix", "")
        for ext in ("h", "cpp"):
            for file in self.filelists[ext]:
                if not first: stream.write(" \\\n    ")
                if prefix: stream.write(f"{prefix}/")
                stream.write(file)
                first = False

    def genHeaderInstalls(self, stream, variables):
        for package in self.packagelist:
            name = "_".join(package.split("/"))
            stream.write(f"{name}dir = $(includedir)/qmf/{package}\n")
            stream.write(f"dist_{name}_HEADERS = ")
            first = True
            for file in self.filelists["h"]:
                if file.startswith(f"qmf/{package}"):
                    if not first: stream.write(" \\\n    ")
                    stream.write(file)
                    first = False
            stream.write("\n\n")

    def testQpidBroker(self, variables):
        return variables.get("qpidbroker", False)

class CMakeLists(Makefile):
    """ Object representing a CMakeLists fragment """
    def unNormCase(self, path):
        return path.replace("\\", "/")

    def genGenSources(self, stream, variables):
        mdir = self.unNormCase(variables["mgenDir"])
        sdir = self.unNormCase(variables["specDir"])
        stream.write(f"{mdir}/qmf-gen\n")
        stream.write(f"    {mdir}/qmfgen/generate.py\n")
        stream.write(f"    {mdir}/qmfgen/schema.py\n")
        stream.write(f"    {mdir}/qmfgen/management-types.xml\n")
        stream.write(f"    {sdir}/management-schema.xml\n")
        for template in self.templateFiles:
            stream.write(f"    {mdir}/qmfgen/templates/{template}\n")

    def _write_file_list(self, stream, files):
        first = True
        for file in files:
            if not first: stream.write(" \n    ")
            stream.write(self.unNormCase(file))
            first = False

    def genGeneratedFiles(self, stream, variables):
        first = True
        prefix = variables.get("genprefix", "")
        for ext in ("h", "cpp"):
            for file in self.filelists[ext]:
                if not first: stream.write(" \n    ")
                if prefix: stream.write(f"{prefix}/")
                stream.write(self.unNormCase(file))
                first = False

    def genHeaderInstalls(self, stream, variables):
        for package in self.packagelist:
            stream.write("#Come back to this later...\n")
            name = "_".join(package.split("/"))
            stream.write(f"#{name}dir = $(includedir)/qmf/{package}\n")
            stream.write(f"#dist_{name}_HEADERS = ")
            first = True
            for file in self.filelists["h"]:
                file = self.unNormCase(file)
                if file.startswith(f"qmf/{package}"):
                    if not first: stream.write("\n    ")
                    stream.write(f"#{file}")
                    first = False
            stream.write("\n\n")

class Generator:
    verbose = False

    def __init__(self, destDir, templateDir):
        self.dest = self.normalize(destDir)
        self.input = self.normalize(templateDir)
        self.packagePath = self.dest
        self.filelists = {"h": [], "cpp": [], "mk": [], "cmake": []}
        self.packagelist = []
        self.templateFiles = []
        self.variables = {}

    def normalize(self, path):
        newpath = os.path.normcase(os.path.normpath(path))
        os.makedirs(newpath, exist_ok=True)
        return newpath + os.path.sep
        
    def setPackage(self, packageName):
        path = os.path.join(*packageName.split("."))
        self.packagelist.append(path.replace("\\", "/"))
        self.packagePath = self.normalize(os.path.join(self.dest, path))

    def testGenQMFv1(self, variables):
        return variables.get("genQmfV1")

    def testGenLogs(self, variables):
        return variables.get("genLogs")

    def testInBroker(self, variables):
        return variables.get('genForBroker')

    def genDisclaimer(self, stream, variables):
        prefix = variables["commentPrefix"]
        stream.write(f"{prefix} This source file was created by a code generator.\n")
        stream.write(f"{prefix} Please do not edit.")

    def genExternClass(self, stream, variables):
        if variables.get('genForBroker'):
            stream.write("QPID_BROKER_CLASS_EXTERN")

    def genExternMethod(self, stream, variables):
        if variables.get('genForBroker'):
            stream.write("QPID_BROKER_EXTERN")

    def fileExt(self, path):
        return os.path.splitext(path)[1]

    def writeIfChanged(self, stream, target, force=False):
        ext = self.fileExt(target).lstrip('.')
        if ext in self.filelists:
            self.filelists[ext].append(target)
        tempFile = target + ".gen.tmp"
        
        with open(tempFile, "w") as fd:
            fd.write(stream.getvalue())

        try:
            if not force and filecmp.cmp(target, tempFile):
                os.remove(tempFile)
                return
        except FileNotFoundError:
            pass

        try:
            os.remove(target)
        except FileNotFoundError:
            pass
        os.rename(tempFile, target)

        if self.verbose:
            print("Generated:", target)

    def _target_file_path(self, basename, extension, prefix=""):
        return os.path.join(self.packagePath, f"{prefix}{basename}{extension}")

    def targetPackageFile(self, schema, templateFile):
        return self._target_file_path("Package", os.path.splitext(templateFile)[1])
    
    def targetV2PackageFile(self, schema, templateFile):
        return self._target_file_path("QmfPackage", os.path.splitext(templateFile)[1])
        
    def targetClassFile(self, _class, templateFile):
        return self._target_file_path(_class.getNameCap(), os.path.splitext(templateFile)[1])

    def targetEventFile(self, event, templateFile):
        return self._target_file_path(event.getNameCap(), os.path.splitext(templateFile)[1], prefix="Event")

    def targetMethodFile(self, method, templateFile):
        return self._target_file_path(method.getFullName(), os.path.splitext(templateFile)[1], prefix="Args")

    def initExpansion(self):
        self.variables = {}

    def substHandler(self, obj, stream, tagObject, tag):
        target_obj = self if tagObject == "Root" else obj
        method_name = f"gen{tag}"
        method = getattr(target_obj, method_name)
        method(stream, self.variables)

    def testCondition(self, obj, tagObject, tag):
        target_obj = self if tagObject == "Root" else obj
        method_name = f"test{tag}"
        method = getattr(target_obj, method_name)
        return method(self.variables)

    def setVariable(self, key, value):
        self.variables[key] = value

    def _make_files(self, templateFile, schema, get_items_func, target_func, force, vars):
        template = Template(os.path.join(self.input, templateFile), self)
        if vars:
            for key, val in vars.items():
                self.setVariable(key, val)
        self.templateFiles.append(templateFile)
        for item in get_items_func(schema):
            target = target_func(item, templateFile)
            stream = template.expand(item)
            self.writeIfChanged(stream, target, force)

    def makeClassFiles(self, templateFile, schema, force=False, vars=None):
        self._make_files(templateFile, schema, lambda s: s.getClasses(), self.targetClassFile, force, vars)

    def makeEventFiles(self, templateFile, schema, force=False, vars=None):
        self._make_files(templateFile, schema, lambda s: s.getEvents(), self.targetEventFile, force, vars)

    def makeMethodFiles(self, templateFile, schema, force=False, vars=None):
        template = Template(os.path.join(self.input, templateFile), self)
        if vars:
            for key, val in vars.items():
                self.setVariable(key, val)
        self.templateFiles.append(templateFile)
        for _class in schema.getClasses():
            for method in _class.getMethods():
                if method.getArgCount() > 0:
                    target = self.targetMethodFile(method, templateFile)
                    stream = template.expand(method)
                    self.writeIfChanged(stream, target, force)

    def makePackageFile(self, templateFile, schema, force=False, vars=None):
        template = Template(os.path.join(self.input, templateFile), self)
        if vars:
            for key, val in vars.items():
                self.setVariable(key, val)
        self.templateFiles.append(templateFile)
        target = self.targetPackageFile(schema, templateFile)
        stream = template.expand(schema)
        self.writeIfChanged(stream, target, force)

    def makeV2PackageFile(self, templateFile, schema, force=False, vars=None):
        template = Template(os.path.join(self.input, templateFile), self)
        if vars:
            for key, val in vars.items():
                self.setVariable(key, val)
        self.templateFiles.append(templateFile)
        target = self.targetV2PackageFile(schema, templateFile)
        stream = template.expand(schema)
        self.writeIfChanged(stream, target, force)

    def makeSingleFile(self, templateFile, target, force=False, vars=None):
        className = os.path.splitext(templateFile)[0]
        if className == "Makefile": classType = Makefile
        elif className == "CMakeLists": classType = CMakeLists
        else: raise ValueError(f"Invalid class name {className}")
            
        makefile = classType(self.filelists, self.templateFiles, self.packagelist)
        template = Template(os.path.join(self.input, templateFile), self)
        if vars:
            for key, val in vars.items():
                self.setVariable(key, val)
        self.templateFiles.append(templateFile)
        stream = template.expand(makefile)
        self.writeIfChanged(stream, target, force)

    @staticmethod
    def getModulePath():
        return __file__