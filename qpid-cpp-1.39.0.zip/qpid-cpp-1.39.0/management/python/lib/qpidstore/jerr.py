#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

# == Warnings =================================================================

class JWarning(Exception):
    """Class to convey a warning"""
    def __init__(self, err):
        """Constructor"""
        super().__init__(err)

# == Errors ===================================================================

class AllJrnlFilesEmptyCsvError(Exception):
    """All journal files are empty (never been written)"""
    def __init__(self, tnum, exp_num_msgs):
        """Constructor"""
        super().__init__(f"[CSV {tnum}] All journal files are empty, but test expects {exp_num_msgs} msg(s).")

class AlreadyLockedError(Exception):
    """Error class for trying to lock a record that is already locked"""
    def __init__(self, rid):
        """Constructor"""
        super().__init__(f"Locking record which is already locked in EnqMap: rid=0x{rid:x}")

class BadFileNumberError(Exception):
    """Error class for incorrect or unexpected file number"""
    def __init__(self, file_num):
        """Constructor"""
        super().__init__(f"Bad file number {file_num}")

class DataSizeError(Exception):
    """Error class for data size mismatch"""
    def __init__(self, exp_size, act_size, data_str):
        """Constructor"""
        super().__init__(f'Inconsistent data size: expected:{exp_size}; actual:{act_size}; data="{data_str}"')

class DeleteLockedRecordError(Exception):
    """Error class for deleting a locked record from the enqueue map"""
    def __init__(self, rid):
        """Constructor"""
        super().__init__(f"Deleting locked record from EnqMap: rid=0x{rid:x}")

class DequeueNonExistentEnqueueError(Exception):
    """Error class for attempting to dequeue a non-existent enqueue record (rid)"""
    def __init__(self, deq_rid):
        """Constructor"""
        super().__init__(f"Dequeuing non-existent enqueue record: rid=0x{deq_rid:x}")

class DuplicateRidError(Exception):
    """Error class for placing duplicate rid into enqueue map"""
    def __init__(self, rid):
        """Constructor"""
        super().__init__(f"Adding duplicate record to EnqMap: rid=0x{rid:x}")

class EndianMismatchError(Exception):
    """Error class for mismatched record header endian flag"""
    def __init__(self, exp_endianness):
        """Constructor"""
        super().__init__(f"Endian mismatch: expected {self.endian_str(exp_endianness)[0]}, but current record is {self.endian_str(exp_endianness)[1]}")

    @staticmethod
    def endian_str(endianness):
        """Return a string tuple for the endianness error message"""
        return ("big", "little") if endianness else ("little", "big")

class ExternFlagDataError(Exception):
    """Error class for the extern flag being set and the internal size > 0"""
    def __init__(self, hdr):
        """Constructor"""
        super().__init__(f"Message data found (msg size > 0) on record with external flag set: hdr={hdr}")

class ExternFlagCsvError(Exception):
    """External flag mismatch between record and CSV test file"""
    def __init__(self, tnum, exp_extern_flag):
        """Constructor"""
        super().__init__(f"[CSV {tnum}] External flag mismatch: expected {exp_extern_flag}")

class ExternFlagWithDataCsvError(Exception):
    """External flag set and Message data found"""
    def __init__(self, tnum):
        """Constructor"""
        super().__init__(f"[CSV {tnum}] Message data found on record with external flag set")

class FillExceedsFileSizeError(Exception):
    """Internal error from a fill operation which will exceed the specified file size"""
    def __init__(self, cur_size, file_size):
        """Constructor"""
        super().__init__(f"Filling to size {cur_size} > max file size {file_size}")

class FillSizeError(Exception):
    """Internal error from a fill operation that did not match the calculated end point in the file"""
    def __init__(self, cur_posn, exp_posn):
        """Constructor"""
        super().__init__(f"Filled to size {cur_posn} > expected file posn {exp_posn}")

class FirstRecordOffsetMismatch(Exception):
    """Error class for file header fro mismatch with actual record"""
    def __init__(self, fro, actual_offs):
        """Constructor"""
        super().__init__(f"File header first record offset mismatch: fro=0x{fro:x}; actual offs=0x{actual_offs:x}")

class InvalidHeaderVersionError(Exception):
    """Error class for invalid record header version"""
    def __init__(self, exp_ver, act_ver):
        """Constructor"""
        super().__init__(f"Invalid header version: expected:{exp_ver}, actual:{act_ver}.")

class InvalidRecordTypeError(Exception):
    """Error class for any operation using an invalid record type"""
    def __init__(self, operation, magic, rid):
        """Constructor"""
        super().__init__(f"Invalid record type for operation: operation={operation} record magic={magic}, rid=0x{rid:x}")

class InvalidRecordTailError(Exception):
    """Error class for invalid record tail"""
    def __init__(self, magic_err, rid_err, rec):
        """Constructor"""
        super().__init__(f" > {rec} *INVALID TAIL RECORD ({self.tail_err_str(magic_err, rid_err)})*")

    @staticmethod
    def tail_err_str(magic_err, rid_err):
        """Return a string indicating the tail record error(s)"""
        errors = []
        if magic_err:
            errors.append("magic bad")
        if rid_err:
            errors.append("rid mismatch")
        return ", ".join(errors)

class NonExistentRecordError(Exception):
    """Error class for any operation on an non-existent record"""
    def __init__(self, operation, rid):
        """Constructor"""
        super().__init__(f"Operation on non-existent record: operation={operation}; rid=0x{rid:x}")

class NotLockedError(Exception):
    """Error class for unlocking a record which is not locked in the first place"""
    def __init__(self, rid):
        """Constructor"""
        super().__init__(f"Unlocking record which is not locked in EnqMap: rid=0x{rid:x}")

class JournalSpaceExceededError(Exception):
    """Error class for when journal space of resized journal is too small to contain the transferred records"""
    def __init__(self):
        """Constructor"""
        super().__init__("Ran out of journal space while writing records")

class MessageLengthCsvError(Exception):
    """Message length mismatch between record and CSV test file"""
    def __init__(self, tnum, exp_msg_len, actual_msg_len):
        """Constructor"""
        super().__init__(f"[CSV {tnum}] Message length mismatch: expected {exp_msg_len}; found {actual_msg_len}")

class NumMsgsCsvError(Exception):
    """Number of messages found mismatched with CSV file"""
    def __init__(self, tnum, exp_num_msgs, actual_num_msgs):
        """Constructor"""
        super().__init__(f"[CSV {tnum}] Incorrect number of messages: expected {exp_num_msgs}, found {actual_num_msgs}")

class TransactionCsvError(Exception):
    """Transaction mismatch between record and CSV file"""
    def __init__(self, tnum, exp_transactional):
        """Constructor"""
        super().__init__(f"[CSV {tnum}] Transaction mismatch: expected {exp_transactional}")

class UnexpectedEndOfFileError(Exception):
    """Error class for unexpected end-of-file during reading"""
    def __init__(self, exp_size, curr_offs):
        """Constructor"""
        super().__init__(f"Unexpected end-of-file: expected file size:{exp_size}; current offset:{curr_offs}")

class XidLengthCsvError(Exception):
    """Message Xid length mismatch between record and CSV file"""
    def __init__(self, tnum, exp_xid_len, actual_msg_len):
        """Constructor"""
        super().__init__(f"[CSV {tnum}] Message XID mismatch: expected {exp_xid_len}; found {actual_msg_len}")

class XidSizeError(Exception):
    """Error class for Xid size mismatch"""
    def __init__(self, exp_size, act_size, xid_str):
        """Constructor"""
        super().__init__(f'Inconsistent xid size: expected:{exp_size}; actual:{act_size}; xid="{xid_str}"')

# =============================================================================

if __name__ == "__main__":
    print("This is a library, and cannot be executed.")