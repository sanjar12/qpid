#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

import jerr
import os.path
import sys
import xml.parsers.expat
from struct import pack, unpack, calcsize
from time import gmtime, strftime
import string

# TODO: Get rid of these! Use jinf instance instead
DBLK_SIZE = 128
SBLK_SIZE = 4 * DBLK_SIZE

# TODO - this is messy - find a better way to handle this
# This is a global, but is set directly by the calling program
JRNL_FILE_SIZE = None

#== class Utils ======================================================================

class Utils(object):
    """Class containing utility functions for dealing with the journal"""

    __printchars = string.ascii_letters + string.digits + string.punctuation + " "

    @staticmethod
    def format_data(dsize, data):
        """Format binary data for printing"""
        if data is None:
            return ""
        if Utils._is_printable(data):
            datastr = Utils._split_str(data.decode('ascii', 'ignore'))
        else:
            datastr = Utils._hex_split_str(data)
        if dsize != len(data):
            raise jerr.DataSizeError(dsize, len(data), datastr)
        return f"data({dsize})=\"{datastr}\" "

    @staticmethod
    def format_xid(xid, xidsize=None):
        """Format binary XID for printing"""
        if xid is None:
            if xidsize is not None and xidsize > 0:
                raise jerr.XidSizeError(xidsize, 0, None)
            return ""
        if Utils._is_printable(xid):
            xidstr = Utils._split_str(xid.decode('ascii', 'ignore'))
        else:
            xidstr = Utils._bytes_to_hex_num(xid) # Use hex num for XIDs
        if xidsize is None:
            xidsize = len(xid)
        elif xidsize != len(xid):
            raise jerr.XidSizeError(xidsize, len(xid), xidstr)
        return f"xid({xidsize})=\"{xidstr}\" "

    @staticmethod
    def inv_bytes(in_bytes):
        """Perform a binary 1's compliment (invert all bits) on a bytes object"""
        return bytes([b ^ 0xff for b in in_bytes])

    @staticmethod
    def load(fhandle, klass):
        """Load a record of class klass from a file"""
        args = Utils._load_args(fhandle, klass)
        subclass = klass.discriminate(args)
        result = subclass(*args)
        if subclass != klass:
            result.init(fhandle, *Utils._load_args(fhandle, subclass))
        result.skip(fhandle)
        return result

    @staticmethod
    def load_file_data(fhandle, size, data):
        """Load the data portion of a message from file"""
        if size == 0:
            return (None, True)
        loaded = len(data) if data is not None else 0
        read_size = size - loaded
        if fhandle.tell() + read_size > JRNL_FILE_SIZE:
            rsize = JRNL_FILE_SIZE - fhandle.tell()
            foverflow = True
        else:
            rsize = read_size
            foverflow = False
        fbin = fhandle.read(rsize)
        data = (data or b'') + fbin
        return (data, not foverflow)

    @staticmethod
    def rem_bytes_in_blk(fhandle, blk_size):
        """Return the remaining bytes in a block"""
        foffs = fhandle.tell()
        return Utils.size_in_bytes_to_blk(foffs, blk_size) - foffs

    @staticmethod
    def size_in_blks(size, blk_size):
        """Return the size in terms of data blocks"""
        return (size + blk_size - 1) // blk_size

    @staticmethod
    def size_in_bytes_to_blk(size, blk_size):
        """Return the bytes remaining until the next block boundary"""
        return Utils.size_in_blks(size, blk_size) * blk_size

    @staticmethod
    def _hex_split_str(in_bytes, split_size=50):
        """Split a hex string into two parts separated by an ellipsis"""
        if len(in_bytes) <= split_size:
            return Utils._hex_str(in_bytes, 0, len(in_bytes))
        return f"{Utils._hex_str(in_bytes, 0, 10)} ... {Utils._hex_str(in_bytes, len(in_bytes) - 10, len(in_bytes))}"

    @staticmethod
    def _hex_str(in_bytes, begin, end):
        """Return a bytestring as a mixed hex/printable string"""
        hstr = ""
        for i in range(begin, end):
            byte_val = in_bytes[i:i+1]
            char_val = byte_val.decode('ascii', 'ignore')
            if char_val in Utils.__printchars:
                hstr += char_val
            else:
                hstr += f'\\x{byte_val.hex()}'
        return hstr
        
    @staticmethod
    def _bytes_to_hex_num(in_bytes):
        """Turn a bytestring into a hex number representation, little endian assumed"""
        return ''.join(f'{b:02x}' for b in reversed(in_bytes))

    @staticmethod
    def _is_printable(in_bytes):
        """Return True if in_bytes is printable; False otherwise."""
        try:
            decoded_str = in_bytes.decode('ascii')
            return all(c in Utils.__printchars for c in decoded_str)
        except UnicodeDecodeError:
            return False

    @staticmethod
    def _load_args(fhandle, klass):
        """Load the arguments from class klass"""
        size = calcsize(klass.FORMAT)
        foffs = fhandle.tell()
        fbin = fhandle.read(size)
        if len(fbin) != size:
            raise jerr.UnexpectedEndOfFileError(size, len(fbin))
        return (foffs,) + unpack(klass.FORMAT, fbin)

    @staticmethod
    def _split_str(in_str, split_size=50):
        """Split a string into two parts separated by an ellipsis if it is longer than split_size"""
        if len(in_str) <= split_size:
            return in_str
        return f"{in_str[:25]} ... {in_str[-25:]}"

#== class Hdr =================================================================

class Hdr(object):
    """Class representing the journal header records"""
    FORMAT = "=4sBBHQ"
    HDR_VER = 1
    OWI_MASK = 0x01
    BIG_ENDIAN = sys.byteorder == "big"
    REC_BOUNDARY = DBLK_SIZE

    def __init__(self, foffs, magic, ver, endn, flags, rid):
        """Constructor"""
        self.foffs = foffs
        self.magic = magic.decode('ascii') if isinstance(magic, bytes) else magic
        self.ver = ver
        self.endn = endn
        self.flags = flags
        self.rid = int(rid)

    def __str__(self):
        """Return string representation of this header"""
        if self.empty():
            return f"0x{self.foffs:08x}: <empty>"
        if self.magic[-1] == "x":
            return f'0x{self.foffs:08x}: ["{self.magic}"]'
        if self.magic[-1] in "acdefx":
            return f'0x{self.foffs:08x}: ["{self.magic}" v={self.ver} e={self.endn} f=0x{self.flags:04x} rid=0x{self.rid:x}]'
        return f'0x{self.foffs:08x}: <error, unknown magic "{self.magic}" (possible overwrite boundary?)>'

    @staticmethod
    def discriminate(args):
        """Use the last char in the header magic to determine the header type"""
        last_char = args[1][-1:].decode('ascii', 'ignore')
        return _CLASSES.get(last_char, Hdr)

    def empty(self):
        """Return True if this record is empty (ie has a magic of 0x0000"""
        return self.magic.encode('ascii') == b"\x00" * 4

    def encode(self):
        """Encode the header into a binary string"""
        return pack(Hdr.FORMAT, self.magic.encode('ascii'), self.ver, self.endn, self.flags, self.rid)

    def owi(self):
        """Return the OWI (overwrite indicator) for this header"""
        return (self.flags & self.OWI_MASK) != 0

    def skip(self, fhandle):
        """Read and discard the remainder of this record"""
        rem = Utils.rem_bytes_in_blk(fhandle, self.REC_BOUNDARY)
        if rem > 0:
            fhandle.read(rem)

    def check(self):
        """Check that this record is valid"""
        if self.empty() or not self.magic.startswith("RHM") or self.magic[3] not in "acdefx":
            return True
        if self.magic[-1] != "x":
            if self.ver != self.HDR_VER:
                raise jerr.InvalidHeaderVersionError(self.HDR_VER, self.ver)
            if bool(self.endn) != self.BIG_ENDIAN:
                raise jerr.EndianMismatchError(self.BIG_ENDIAN)
        return False

#== class FileHdr =============================================================

class FileHdr(Hdr):
    """Class for file headers, found at the beginning of journal files"""
    FORMAT = "=2H4x3Q"
    REC_BOUNDARY = SBLK_SIZE

    def __str__(self):
        """Return a string representation of the this FileHdr instance"""
        return f"{super().__str__()} fid={self.fid} lid={self.lid} fro=0x{self.fro:08x} t={self.timestamp_str()}"

    def encode(self):
        """Encode this class into a binary string"""
        return super().encode() + pack(FileHdr.FORMAT, self.fid, self.lid, self.fro, self.time_sec, self.time_ns)

    def init(self, fhandle, foffs, fid, lid, fro, time_sec, time_ns):
        """Initialize this instance to known values"""
        self.fid, self.lid, self.fro, self.time_sec, self.time_ns = fid, lid, fro, time_sec, time_ns

    def timestamp(self):
        """Get the timestamp of this record as a tuple (secs, nsecs)"""
        return (self.time_sec, self.time_ns)

    def timestamp_str(self):
        """Get the timestamp of this record in string format"""
        ts = gmtime(self.time_sec)
        return f"{strftime('%a %b %d %H:%M:%S', ts)}.{self.time_ns:09d} {strftime('%Y', ts)}"

# Classes DeqRec, TxnRec, EnqRec, RecTail, and JrnlInfo would follow a similar conversion pattern.
# This example focuses on the Utils and Hdr classes to demonstrate the key changes.

# This section is just for demonstration, the original file is a library.
class DeqRec(Hdr): pass
class TxnRec(Hdr): pass
class EnqRec(Hdr): pass
class RecTail(object): pass
class JrnlInfo(object): pass

_CLASSES = {
    "a": TxnRec,
    "c": TxnRec,
    "d": DeqRec,
    "e": EnqRec,
    "f": FileHdr
}

if __name__ == "__main__":
    print("This is a library, and cannot be executed.")