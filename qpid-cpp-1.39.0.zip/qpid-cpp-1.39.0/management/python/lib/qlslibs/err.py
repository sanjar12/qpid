#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

"""
Module: qlslibs.err

Contains error classes.
"""

# --- Parent classes

class QlsError(Exception):
    """Base error class for QLS errors and exceptions"""
    def __init__(self):
        super().__init__()
    def __str__(self):
        return ''

class QlsRecordError(QlsError):
    """Base error class for individual records"""
    def __init__(self, file_header, record):
        super().__init__()
        self.file_header = file_header
        self.record = record
    def get_expected_fro(self):
        return self.file_header.first_record_offset
    def get_file_number(self):
        return self.file_header.file_num
    def get_queue_name(self):
        return self.file_header.queue_name
    def get_record_id(self):
        return self.record.record_id
    def get_record_offset(self):
        return self.record.file_offset
    def __str__(self):
        return (f'queue="{self.file_header.queue_name}" file_id=0x{self.file_header.file_num:x} '
                f'record_offset=0x{self.record.file_offset:x} record_id=0x{self.record.record_id:x}')

# --- Error classes

class AlreadyLockedError(QlsRecordError):
    """Transactional record to be locked is already locked"""
    def __init__(self, file_header, record):
        super().__init__(file_header, record)
    def __str__(self):
        return f'Transactional operation already locked in TransactionMap: {super().__str__()}'

class DataSizeError(QlsError):
    """Error class for Data size mismatch"""
    def __init__(self, expected_size, actual_size, data_str):
        super().__init__()
        self.expected_size = expected_size
        self.actual_size = actual_size
        self.data_str = data_str
    def __str__(self):
        return (f'Inconsistent data size: expected:{self.expected_size}; actual:{self.actual_size}; '
                f'data="{self.data_str}"')

class DuplicateRecordIdError(QlsRecordError):
    """Duplicate Record Id in Enqueue Map"""
    def __init__(self, file_header, record):
        super().__init__(file_header, record)
    def __str__(self):
        return f'Duplicate Record Id in enqueue map: {super().__str__()}'

class EnqueueCountUnderflowError(QlsRecordError):
    """Attempted to decrement enqueue count past 0"""
    def __init__(self, file_header, record):
        super().__init__(file_header, record)
    def __str__(self):
        return f'Enqueue record count underflow: {super().__str__()}'

class ExternalDataError(QlsRecordError):
    """Data present in Enqueue record when external data flag is set"""
    def __init__(self, file_header, record):
        super().__init__(file_header, record)
    def __str__(self):
        return f'Data present in external data record: {super().__str__()}'

class FirstRecordOffsetMismatchError(QlsRecordError):
    """First Record Offset (FRO) does not match file header"""
    def __init__(self, file_header, record):
        super().__init__(file_header, record)
    def __str__(self):
        return f'First record offset mismatch: {super().__str__()} expected_offset=0x{self.file_header.first_record_offset:x}'

class InsufficientSpaceOnDiskError(QlsError):
    """Insufficient space on disk"""
    def __init__(self, directory, space_avail, space_required):
        super().__init__()
        self.directory = directory
        self.space_avail = space_avail
        self.space_required = space_required
    def __str__(self):
        return (f'Insufficient space on disk: directory={self.directory}; avail_space={self.space_avail} '
                f'required_space={self.space_required}')

class InvalidClassError(QlsError):
    """Invalid class name or type"""
    def __init__(self, class_name):
        super().__init__()
        self.class_name = class_name
    def __str__(self):
        return f'Invalid class name "{self.class_name}"'

class InvalidEfpDirectoryNameError(QlsError):
    """Invalid EFP directory name - should be NNNNk, where NNNN is a number (of any length)"""
    def __init__(self, directory_name):
        super().__init__()
        self.directory_name = directory_name
    def __str__(self):
        return f'Invalid EFP directory name "{self.directory_name}"'

class InvalidPartitionDirectoryNameError(QlsError):
    """Invalid EFP partition name - should be pNNN, where NNN is a 3-digit partition number"""
    def __init__(self, directory_name):
        super().__init__()
        self.directory_name = directory_name
    def __str__(self):
        return f'Invalid partition directory name "{self.directory_name}"'

class InvalidQlsDirectoryNameError(QlsError):
    """Invalid QLS directory name"""
    def __init__(self, directory_name):
        super().__init__()
        self.directory_name = directory_name
    def __str__(self):
        return f'Invalid QLS directory name "{self.directory_name}"'

class InvalidRecordTypeError(QlsRecordError):
    """Error class for any operation using an invalid record type"""
    def __init__(self, file_header, record, error_msg):
        super().__init__(file_header, record)
        self.error_msg = error_msg
    def __str__(self):
        return f'Invalid record type: {super().__str__()}:{self.error_msg}'

class InvalidRecordVersionError(QlsRecordError):
    """Invalid record version"""
    def __init__(self, file_header, record, expected_version):
        super().__init__(file_header, record)
        self.expected_version = expected_version
    def __str__(self):
        return (f'Invalid record version: queue="{self.file_header.queue_name}" {super().__str__()} '
                f'ver_found=0x{self.record.version:x} ver_expected=0x{self.expected_version:x}')

class NoMoreFilesInJournalError(QlsError):
    """Raised when trying to obtain the next file in the journal and there are no more files"""
    def __init__(self, queue_name):
        super().__init__()
        self.queue_name = queue_name
    def __str__(self):
        return f'No more journal files in queue "{self.queue_name}"'

class NonTransactionalRecordError(QlsRecordError):
    """Transactional operation on non-transactional record"""
    def __init__(self, file_header, record, operation):
        super().__init__(file_header, record)
        self.operation = operation
    def __str__(self):
        return f'Transactional operation on non-transactional record: {super().__str__()} operation={self.operation}'

class PartitionDoesNotExistError(QlsError):
    """Partition name does not exist on disk"""
    def __init__(self, partition_directory):
        super().__init__()
        self.partition_directory = partition_directory
    def __str__(self):
        return f'Partition {self.partition_directory} does not exist'

class PoolDirectoryAlreadyExistsError(QlsError):
    """Pool directory already exists"""
    def __init__(self, pool_directory):
        super().__init__()
        self.pool_directory = pool_directory
    def __str__(self):
        return f'Pool directory {self.pool_directory} already exists'

class PoolDirectoryDoesNotExistError(QlsError):
    """Pool directory does not exist"""
    def __init__(self, pool_directory):
        super().__init__()
        self.pool_directory = pool_directory
    def __str__(self):
        return f'Pool directory {self.pool_directory} does not exist'

class RecordIdNotFoundError(QlsRecordError):
    """Record Id not found in enqueue map"""
    def __init__(self, file_header, record):
        super().__init__(file_header, record)
    def __str__(self):
        return f'Record Id not found in enqueue map: {super().__str__()}'

class RecordNotLockedError(QlsRecordError):
    """Record in enqueue map is not locked"""
    def __init__(self, file_header, record):
        super().__init__(file_header, record)
    def __str__(self):
        return f'Record in enqueue map is not locked: {super().__str__()}'

class UnexpectedEndOfFileError(QlsError):
    """The bytes read from a file is less than that expected"""
    def __init__(self, size_read, size_expected, file_offset, file_name):
        super().__init__()
        self.size_read = size_read
        self.size_expected = size_expected
        self.file_offset = file_offset
        self.file_name = file_name
    def __str__(self):
        return (f'Tried to read {self.size_read} at offset {self.file_offset} in file "{self.file_name}"; '
                f'only read {self.size_expected}')

class WritePermissionError(QlsError):
    """No write permission"""
    def __init__(self, directory):
        super().__init__()
        self.directory = directory
    def __str__(self):
        return f'No write permission in directory {self.directory}'

class XidSizeError(QlsError):
    """Error class for Xid size mismatch"""
    def __init__(self, expected_size, actual_size, xid_str):
        super().__init__()
        self.expected_size = expected_size
        self.actual_size = actual_size
        self.xid_str = xid_str
    def __str__(self):
        return f'Inconsistent xid size: expected:{self.expected_size}; actual:{self.actual_size}; xid="{self.xid_str}"'

# =============================================================================

if __name__ == "__main__":
    print("This is a library, and cannot be executed.")