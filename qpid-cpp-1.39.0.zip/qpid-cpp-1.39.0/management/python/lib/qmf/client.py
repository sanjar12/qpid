#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License
#

"""
AMQP 1.0 QMF client for the Qpid C++ broker.

This client is based on the Qpid-Proton library which only supports AMQP 1.0, it
is intended for forward-looking projects that want to move to the newer client
libraries. One important feature is that it does not start background threads,
which makes it more suitable for environments that may fork.
"""
from proton import Message
from proton.utils import BlockingConnection, IncomingMessageHandler, ConnectionException
import threading
import struct
import time

class ReconnectDelays(object):
    """
    An iterable that returns a (possibly unlimited) sequence of delays to for
    successive reconnect attempts.
    """

    def __init__(self, shortest, longest, repeat=True):
        """
        First delay is 0, then `shortest`. Successive delays are doubled up to a
        maximum of `longest`. If `repeat` is a number > 0 then the `longest` value
        is generated `repeat` more times.  If `repeat` is True, the longest
        value is returned without limit.

        For example: ReconnectDelays(.125, 1, True) will generate the following sequence:
            0, .125, .25, .5, 1, 1, 1, 1, 1, 1 ... (forever)
        """
        if shortest <= 0 or shortest > longest or repeat < 0:
            raise ValueError("invalid arguments for reconnect_delays()")
        self.shortest, self.longest, self.repeat = shortest, longest, repeat

    def _generate(self):
        yield 0
        delay = self.shortest
        while delay < self.longest:
            yield delay
            delay *= 2
        yield self.longest
        if self.repeat is True:
            while True:
                yield self.longest
        elif self.repeat:
            for i in range(self.repeat):
                yield self.longest

    def __iter__(self):
        return self._generate()

class SyncRequestResponse(IncomingMessageHandler):
    """
    Implementation of the synchronous request-responce (aka RPC) pattern.
    @ivar address: Address for all requests, may be None.
    @ivar connection: Connection for requests and responses.
    """

    def __init__(self, connection, address=None):
        """
        Send requests and receive responses. A single instance can send many requests
        to the same or different addresses.

        @param connection: A L{BlockingConnection}
        @param address: Address for all requests.
            If not specified, each request must have the address property set.
            Sucessive messages may have different addresses.
        """
        super().__init__()
        self.address = address
        self.response = None
        self._cid = 0
        self.lock = threading.Lock()
        self.reconnect(connection)

    def reconnect(self, connection):
        self.connection = connection
        self.sender = self.connection.create_sender(self.address)
        self.receiver = self.connection.create_receiver(None, dynamic=True, credit=1, handler=self)

    def _next(self):
        """Get the next correlation ID"""
        with self.lock:
            self._cid += 1
            return struct.pack("I", self._cid).decode('ascii')

    def call(self, request):
        """
        Send a request message, wait for and return the response message.

        @param request: A L{proton.Message}. If L{self.address} is not set the
            L{self.address} must be set and will be used.
        """
        return self.wait(self.send(request))

    def send(self, request):
        """
        Send a request and return the correlation_id immediately. Use wait() to get the response.
        @param request: A L{proton.Message}. If L{self.address} is not set the
            L{self.address} must be set and will be used.
        """
        if not self.address and not request.address:
            raise ValueError(f"Request message has no address: {request}")
        request.reply_to = self.reply_to
        request.correlation_id = self._next()
        self.sender.send(request)
        return request.correlation_id

    def wait(self, correlation_id):
        """Wait for and return a single response to a request previously sent with send()"""
        def wakeup():
            return self.response and (self.response.correlation_id == correlation_id)
        self.connection.wait(wakeup, msg="Waiting for response")
        response = self.response
        self.response = None
        self.receiver.flow(1)
        return response

    @property
    def reply_to(self):
        """Return the dynamic address of our receiver."""
        return self.receiver.remote_source.address

    def on_message(self, event):
        """Called when we receive a message for our receiver."""
        self.response = event.message
        self.connection.container.yield_()

class BrokerAgent(object):
    """Proxy for a manageable Qpid broker"""

    @staticmethod
    def connection(url=None, timeout=10, ssl_domain=None, sasl=None):
        """Return a BlockingConnection suitable for use with a BrokerAgent."""
        return BlockingConnection(url,
                                  timeout=timeout,
                                  ssl_domain=ssl_domain,
                                  allowed_mechs=str(sasl.mechs) if sasl else None,
                                  user=str(sasl.user) if sasl else None,
                                  password=str(sasl.password) if sasl else None)

    @staticmethod
    def connect(url=None, timeout=10, ssl_domain=None, sasl=None, reconnect_delays=None):
        """
        Return a BrokerAgent connected with the given parameters.
        @param reconnect_delays: iterable of delays for successive automatic re-connect attempts,
        see class ReconnectDelays. If None there is no automatic re-connect
        """
        f = lambda: BrokerAgent.connection(url, timeout, ssl_domain, sasl)
        ba = BrokerAgent(f())
        ba.make_connection = f
        ba.reconnect_delays = reconnect_delays or []
        return ba

    def __init__(self, connection):
        """
        Create a management node proxy using the given connection.
        @param connection: a L{BlockingConnection} to the management agent.
        """
        path = connection.url.path or "qmf.default.direct"
        self._client = SyncRequestResponse(connection, path)
        self.reconnect_delays = None

    def reconnect(self, connection):
        self._client.reconnect(connection)

    def close(self):
        """Shut down the node"""
        if self._client:
            self._client.connection.close()
            self._client = None

    def __repr__(self):
        return f"{self.__class__.__name__}({self._client.connection.url})"

    def _reconnect(self):
        for d in self.reconnect_delays:
            time.sleep(d)
            try:
                self.reconnect(self.make_connection())
                return True
            except ConnectionException:
                pass
        return False

    def _retry(self, f, *args, **kwargs):
        while True:
            try:
                return f(*args, **kwargs)
            except ConnectionException:
                if not self._reconnect():
                    raise

    def _request(self, opcode, content):
        props = {'method': 'request',
                 'qmf.opcode': opcode,
                 'x-amqp-0-10.app-id': 'qmf2'}
        return self._client.call(Message(body=content, properties=props, subject="broker"))

    def _method(self, method, arguments=None, addr="org.apache.qpid.broker:broker:amqp-broker"):
        """
        Make a L{proton.Message} containing a QMF method request.
        """
        content = {'_object_id': {'_object_name': addr},
                   '_method_name': method,
                   '_arguments': arguments or {}}
        response = self._retry(self._request, 'request', content) # opcode changed for clarity
        if response.properties['qmf.opcode'] == '_exception':
            raise Exception(f"management error: {response.body.get('_values')!r}")
        if response.properties['qmf.opcode'] != '_method_response':
            raise Exception(f"bad response: {response.properties!r}")
        return response.body.get('_arguments', {})

    def _gather(self, response):
        items = response.body
        while 'partial' in response.properties:
            response = self._client.wait(response.correlation_id)
            items += response.body
        return items

    def _classQuery(self, class_name):
        query = {'_what': 'OBJECT', '_schema_id': {'_class_name': class_name}}
        def f():
            response = self._request('_query_request', query)
            if response.properties['qmf.opcode'] != '_query_response':
                raise Exception("bad response")
            return self._gather(response)
        return self._retry(f)

    def _nameQuery(self, object_id):
        query = {'_what': 'OBJECT', '_object_id': {'_object_name': object_id}}
        def f():
            response = self._request('_query_request', query)
            if response.properties['qmf.opcode'] != '_query_response':
                raise Exception("bad response")
            items = self._gather(response)
            return items[0] if len(items) == 1 else None
        return self._retry(f)

    def _getAll(self, cls):
        return [cls(self, x) for x in self._classQuery(cls.__name__.lower())]

    def _getSingle(self, cls):
        l = self._getAll(cls)
        return l[0] if l else None

    def _get(self, cls, oid):
        x = self._nameQuery(oid)
        return cls(self, x) if x else None

    def getBroker(self): return self._getSingle(Broker)
    def getCluster(self): return self._getSingle(Cluster)
    def getHaBroker(self): return self._getSingle(HaBroker)
    def getAllConnections(self): return self._getAll(Connection)
    def getConnection(self, oid): return self._get(Connection, f"org.apache.qpid.broker:connection:{oid}")
    def getAllSessions(self): return self._getAll(Session)
    def getSession(self, oid): return self._get(Session, f"org.apache.qpid.broker:session:{oid}")
    def getAllSubscriptions(self): return self._getAll(Subscription)
    def getSubscription(self, oid): return self._get(Subscription, f"org.apache.qpid.broker:subscription:{oid}")
    def getAllExchanges(self): return self._getAll(Exchange)
    def getExchange(self, name): return self._get(Exchange, f"org.apache.qpid.broker:exchange:{name}")
    def getAllQueues(self): return self._getAll(Queue)
    def getQueue(self, name): return self._get(Queue, f"org.apache.qpid.broker:queue:{name}")
    def getAllBindings(self): return self._getAll(Binding)
    def getAllLinks(self): return self._getAll(Link)
    def getAcl(self): return self._getSingle(Acl)
    def getMemory(self): return self._getSingle(Memory)

    def echo(self, sequence=1, body="Body"):
        return self._method('echo', {'sequence': sequence, 'body': body})

    def queueMoveMessages(self, srcQueue, destQueue, qty):
        self._method("queueMoveMessages", {'srcQueue': srcQueue, 'destQueue': destQueue, 'qty': qty})

    def queueRedirect(self, sourceQueue, targetQueue):
        self._method("queueRedirect", {'sourceQueue': sourceQueue, 'targetQueue': targetQueue})

    def setLogLevel(self, level):
        self._method("setLogLevel", {'level': level})

    def getLogLevel(self):
        return self._method('getLogLevel')

    def setTimestampConfig(self, receive):
        self._method("setTimestampConfig", {'receive': receive})

    def getTimestampConfig(self):
        return self._method('getTimestampConfig')

    def setLogHiresTimestamp(self, logHires):
        self._method("setLogHiresTimestamp", {'logHires': logHires})

    def getLogHiresTimestamp(self):
        return self._method('getLogHiresTimestamp')

    def addExchange(self, exchange_type, name, options={}, **kwargs):
        properties = {'exchange-type': exchange_type}
        properties.update(options)
        properties.update(kwargs)
        args = {'type': 'exchange', 'name': name, 'properties': properties, 'strict': True}
        self._method('create', args)

    def delExchange(self, name):
        self._method('delete', {'type': 'exchange', 'name': name})

    def addQueue(self, name, options={}, **kwargs):
        properties = {}
        properties.update(options)
        properties.update(kwargs)
        args = {'type': 'queue', 'name': name, 'properties': properties, 'strict': True}
        self._method('create', args)

    def delQueue(self, name, if_empty=True, if_unused=True):
        options = {'if_empty': if_empty, 'if_unused': if_unused}
        self._method('delete', {'type': 'queue', 'name': name, 'options': options})

    def bind(self, exchange, queue, key="", options={}, **kwargs):
        properties = {}
        properties.update(options)
        properties.update(kwargs)
        args = {'type': 'binding', 'name': f"{exchange}/{queue}/{key}", 'properties': properties, 'strict': True}
        self._method('create', args)

    def unbind(self, exchange, queue, key, **kwargs):
        self._method('delete', {'type': 'binding', 'name': f"{exchange}/{queue}/{key}", 'strict': True})

    def reloadAclFile(self):
        self._method('reloadACLFile', {}, "org.apache.qpid.acl:acl:org.apache.qpid.broker:broker:amqp-broker")

    def acl_lookup(self, userName, action, aclObj, aclObjName, propMap):
        args = {'userId': userName, 'action': action, 'object': aclObj, 'objectName': aclObjName, 'propertyMap': propMap}
        return self._method('Lookup', args, "org.apache.qpid.acl:acl:org.apache.qpid.broker:broker:amqp-broker")

    def acl_lookupPublish(self, userName, exchange, key):
        args = {'userId': userName, 'exchangeName': exchange, 'routingKey': key}
        return self._method('LookupPublish', args, "org.apache.qpid.acl:acl:org.apache.qpid.broker:broker:amqp-broker")

    def Redirect(self, sourceQueue, targetQueue):
        args = {'sourceQueue': sourceQueue, 'targetQueue': targetQueue}
        return self._method('queueRedirect', args, "org.apache.qpid.broker:broker:amqp-broker")

    def create(self, _type, name, properties={}, strict=False):
        args = {'type': _type, 'name': name, 'properties': properties, 'strict': strict}
        return self._method('create', args)

    def delete(self, _type, name, options):
        args = {'type': _type, 'name': name, 'options': options}
        return self._method('delete', args)

    def list(self, _type):
        return [i["_values"] for i in self._classQuery(_type.lower())]

    def query(self, _type, oid):
        return self._get(self, _type, oid)

class BrokerObject(object):
    def __init__(self, broker, content):
        self.broker = broker
        self.content = content

    @property
    def values(self):
        return self.content['_values']

    def __getattr__(self, key):
        return self.values.get(key)

    def getObjectId(self):
        return self.content['_object_id']['_object_name']

    def getAttributes(self):
        return self.values

    def getCreateTime(self):
        return self.content['_create_ts']

    def getDeleteTime(self):
        return self.content['_delete_ts']

    def getUpdateTime(self):
        return self.content['_update_ts']

    def update(self):
        """Reload the property values from the agent."""
        refreshed = self.broker._get(self.__class__, self.getObjectId())
        if refreshed:
            self.content = refreshed.content
        else:
            raise Exception("No longer exists on the broker")

    def __repr__(self):
        return f"{self.__class__.__name__}({self.content})"

    def __str__(self):
        return self.getObjectId()

class Broker(BrokerObject):
    pass
class Cluster(BrokerObject):
    pass
class HaBroker(BrokerObject):
    pass
class Memory(BrokerObject):
    pass
class Connection(BrokerObject):
    def close(self):
        self.broker._method("close", {}, f"org.apache.qpid.broker:connection:{self.address}")
class Session(BrokerObject):
    pass
class Subscription(BrokerObject):
    pass
class Exchange(BrokerObject):
    pass
class Binding(BrokerObject):
    pass
class Queue(BrokerObject):
    def purge(self, request):
        """Discard all or some messages on a queue"""
        self.broker._method("purge", {'request': request}, f"org.apache.qpid.broker:queue:{self.name}")

    def reroute(self, request, useAltExchange, exchange, filter={}):
        """Remove all or some messages on this queue and route them to an exchange"""
        args = {'request': request, 'useAltExchange': useAltExchange, 'exchange': exchange, 'filter': filter}
        self.broker._method("reroute", args, f"org.apache.qpid.broker:queue:{self.name}")
class Link(BrokerObject):
    pass
class Acl(BrokerObject):
    pass