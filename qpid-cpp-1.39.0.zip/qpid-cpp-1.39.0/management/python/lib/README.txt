To run these programs, please set PYTHONPATH to include:

   qpid/python
   qpid/extras/qmf/src/py
