#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#
"""Utilities for managing configuration files"""
import os

QPID_ENV_PREFIX = "QPID_"

def parse_qpidd_conf(config_file):
    """
    Parse a qpidd.conf configuration file into a dictionary.

    Reads key-value pairs from the config file, then overrides them with
    any environment variables that start with QPID_.
    """
    config = {}

    # 1. Use a 'with' statement for safer file handling.
    with open(config_file, 'r') as f:
        for line in f:
            # Strip comments and leading/trailing whitespace.
            line = line.split('#', 1)[0].strip()
            # Parse 'key=value' pairs.
            if '=' in line:
                key, value = line.split('=', 1)
                config[key.strip()] = value.strip()

    # 2. Find environment variables and override config values.
    #    os.environ.iteritems() is replaced with os.environ.items().
    env_config = {
        key[len(QPID_ENV_PREFIX):].lower(): value
        for key, value in os.environ.items()
        if key.startswith(QPID_ENV_PREFIX)
    }

    # Environment variables take precedence over the file's config.
    config.update(env_config)
    return config