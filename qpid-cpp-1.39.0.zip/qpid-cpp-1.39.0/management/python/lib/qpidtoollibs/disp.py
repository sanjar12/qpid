#!/usr/bin/env python

#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#
from __future__ import print_function

from time import strftime, gmtime
from functools import total_ordering

def YN(val):
  if val:
    return 'Y'
  return 'N'

def Commas(value):
  sval = str(value)
  result = ""
  while True:
    if len(sval) == 0:
      return result
    left = sval[:-3]
    right = sval[-3:]
    result = right + result
    if len(left) > 0:
      result = ',' + result
    sval = left

def TimeLong(value):
  return strftime("%c", gmtime(value // 1000000000))

def TimeShort(value):
  return strftime("%X", gmtime(value // 1000000000))


class Header(object):
  """ """
  NONE = 1
  KMG = 2
  YN = 3
  Y = 4
  TIME_LONG = 5
  TIME_SHORT = 6
  DURATION = 7
  COMMAS = 8

  def __init__(self, text, format=NONE):
    self.text = text
    self.format = format

  def __repr__(self):
    return self.text

  def __str__(self):
    return self.text

  def formatted(self, value):
    try:
      if value is None:
        return ''
      if self.format == Header.NONE:
        return value
      if self.format == Header.KMG:
        return self.num(value)
      if self.format == Header.YN:
        return 'Y' if value else 'N'
      if self.format == Header.Y:
        return 'Y' if value else ''
      if self.format == Header.TIME_LONG:
         return TimeLong(value)
      if self.format == Header.TIME_SHORT:
         return TimeShort(value)
      if self.format == Header.DURATION:
        if value < 0: value = 0
        sec = value // 1000000000
        min_val, s = divmod(sec, 60)
        hour, m = divmod(min_val, 60)
        day, h = divmod(hour, 24)
        result = ""
        if day > 0:
          result = f"{day}d "
        if h > 0 or result != "":
          result += f"{h}h "
        if m > 0 or result != "":
          result += f"{m}m "
        result += f"{s}s"
        return result
      if self.format == Header.COMMAS:
        return Commas(value)
    except:
      return "?"
    return str(value)

  def numCell(self, value, tag):
    fp = float(value) / 1000.
    if fp < 10.0:
      return f"{fp:1.2f}{tag}"
    if fp < 100.0:
      return f"{fp:2.1f}{tag}"
    return f"{value // 1000:4d}{tag}"

  def num(self, value):
    if value < 1000:
      return f"{value:4d}"
    if value < 1000000:
      return self.numCell(value, 'k')
    value //= 1000
    if value < 1000000:
      return self.numCell(value, 'm')
    value //= 1000
    return self.numCell(value, 'g')


class Display(object):
  """ Display formatting for QPID Management CLI """
  
  def __init__(self, spacing=2, prefix="    "):
    self.tableSpacing    = spacing
    self.tablePrefix     = prefix
    self.timestampFormat = "%X"

  def formattedTable(self, title, heads, rows):
    fRows = [[heads[i].formatted(cell) for i, cell in enumerate(row)] for row in rows]
    headtext = [head.text for head in heads]
    self.table(title, headtext, fRows)

  def table(self, title, heads, rows):
    """ Print a table with autosized columns """
    for row in rows:
        while len(row) < len(heads):
            row.append("")

    print(title)
    if not rows:
      return

    colWidth = []
    for i, head in enumerate(heads):
        width = len(head)
        for row in rows:
            cell_text = str(row[i])
            cellWidth = len(cell_text)
            if cellWidth > width:
                width = cellWidth
        colWidth.append(width)

    header_line = self.tablePrefix + "".join(
        f"{head:<{colWidth[i] + self.tableSpacing}}" for i, head in enumerate(heads)
    ).rstrip()
    print(header_line)
    
    separator_line = self.tablePrefix + "".join(
        "=" * (width + self.tableSpacing) for width in colWidth
    ).rstrip()
    print(separator_line[:255])

    for row in rows:
        row_line = self.tablePrefix + "".join(
            f"{str(cell):<{colWidth[i] + self.tableSpacing}}" for i, cell in enumerate(row)
        ).rstrip()
        print(row_line)

  def do_setTimeFormat(self, fmt):
    """ Select timestamp format """
    if fmt == "long":
      self.timestampFormat = "%c"
    elif fmt == "short":
      self.timestampFormat = "%X"

  def timestamp(self, nsec):
    """ Format a nanosecond-since-the-epoch timestamp for printing """
    return strftime(self.timestampFormat, gmtime(nsec // 1000000000))

  def duration(self, nsec):
    if nsec < 0: nsec = 0
    sec, _ = divmod(nsec, 1000000000)
    min_val, s = divmod(sec, 60)
    hour, m = divmod(min_val, 60)
    day, h = divmod(hour, 24)
    result = ""
    if day > 0:
      result = f"{day}d "
    if h > 0 or result != "":
      result += f"{h}h "
    if m > 0 or result != "":
      result += f"{m}m "
    result += f"{s}s"
    return result

@total_ordering
class Sortable(object):
  """ """
  def __init__(self, row, sortIndex):
    self.row = row
    self.sortIndex = sortIndex
    if sortIndex >= len(row):
      raise IndexError("sort index exceeds row boundary")

  def __eq__(self, other):
    if not isinstance(other, Sortable):
        return NotImplemented
    return self.row[self.sortIndex] == other.row[self.sortIndex]

  def __lt__(self, other):
    if not isinstance(other, Sortable):
        return NotImplemented
    val1 = self.row[self.sortIndex]
    val2 = other.row[self.sortIndex]
    if val1 is None and val2 is None: return False
    if val1 is None: return True
    if val2 is None: return False
    try:
        return val1 < val2
    except TypeError:
        return str(val1) < str(val2)

  def getRow(self):
    return self.row

class Sorter(object):
  """ """
  def __init__(self, heads, rows, sortCol, limit=0, inc=True):
    col = -1
    for i, head in enumerate(heads):
      if head.text == sortCol:
        col = i
        break
    if col == -1:
      raise ValueError(f"sortCol '{sortCol}', not found in headers")

    sortable_list = [Sortable(row, col) for row in rows]
    sortable_list.sort(reverse=not inc)

    if limit > 0:
        self.sorted = [item.getRow() for item in sortable_list[:limit]]
    else:
        self.sorted = [item.getRow() for item in sortable_list]

  def getSorted(self):
    return self.sorted